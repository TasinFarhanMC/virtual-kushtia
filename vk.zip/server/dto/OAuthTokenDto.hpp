// OAuthTokenDto.hpp
#ifndef OAuthTokenDto_hpp
#define OAuthTokenDto_hpp

#include "oatpp/core/Types.hpp"
#include "oatpp/core/macro/codegen.hpp"

#include OATPP_CODEGEN_BEGIN(DTO)

class OAuthTokenDto : public oatpp::DTO {
  DTO_INIT(OAuthTokenDto, DTO)

  DTO_FIELD(String, access_token);
  DTO_FIELD(Int32, expires_in);
  DTO_FIELD(String, token_type);
  // Optionally, you can also include refresh_token and scope if needed.
};

#include OATPP_CODEGEN_END(DTO)

#endif // OAuthTokenDto_hpp
