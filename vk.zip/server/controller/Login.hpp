#pragma once

#include <dto/DTOs.hpp>
#include <dto/Login.hpp>

#include "oatpp/core/macro/codegen.hpp"
#include "oatpp/core/macro/component.hpp"
#include "oatpp/web/server/api/ApiController.hpp"

#include OATPP_CODEGEN_BEGIN(ApiController)

using namespace oatpp;

class LoginCon : public web::server::api::ApiController {
public:
  /**
   * Constructor with object mapper.
   * @param objectMapper - default object mapper used to serialize/deserialize DTOs.
   */
  LoginCon(OATPP_COMPONENT(std::shared_ptr<ObjectMapper>, objectMapper))
      : web::server::api::ApiController(objectMapper) {}

public:
  ENDPOINT("POST", "/api/login", login, BODY_DTO(Object<LoginDto>, requestDto)) {
    OATPP_LOGI("LoginEndpoint", "Received username: %s", requestDto->email->c_str());
    OATPP_LOGI("LoginEndpoint", "Received password: %s", requestDto->password->c_str());

    // Create a response DTO
    auto responseDto = MyDto::createShared();
    responseDto->statusCode = 200;
    responseDto->message = "Login successful!";

    return createDtoResponse(Status::CODE_200, responseDto);
  }
};

#include OATPP_CODEGEN_END(ApiController)
