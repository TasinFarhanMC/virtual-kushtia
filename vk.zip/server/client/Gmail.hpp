#include <oatpp-curl/RequestExecutor.hpp>
#include <oatpp/core/data/mapping/ObjectMapper.hpp>

namespace Api {
class Gmail {
public:
  Gmail(const std::shared_ptr<oatpp::data::mapping::ObjectMapper> &obj_mapper);
  void refresh_token();

private:
  const std::shared_ptr<oatpp::curl::RequestExecutor> con =
      oatpp::curl::RequestExecutor::createShared("https://oauth2.googleapis.com");

  const std::shared_ptr<oatpp::data::mapping::ObjectMapper> obj_mapper;
};
} // namespace Api
