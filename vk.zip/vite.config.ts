import { sveltekit } from '@sveltejs/kit/vite';
import { defineConfig } from 'vite';

/** @type {import('vite').UserConfig} */
export default defineConfig(({ command }) => ({
  plugins: [sveltekit()],
  server: {
    proxy: command === 'serve' ? {
      '/api': {
        target: 'http://localhost:8080',
        changeOrigin: true,
        secure: false,
      }
    } : undefined
  }
}));
