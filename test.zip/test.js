const fs = require('fs').promises;

async function loadSecrets() {
  try {
    const data = await fs.readFile('token.json', 'utf-8');
    const parsedData = JSON.parse(data);

    // Return the relevant secrets from the JSON structure
    return {
      refreshToken: parsedData.refresh_token,
      clientId: parsedData.client_id,
      clientSecret: parsedData.client_secret,
      tokenUri: parsedData.token_uri,
      scopes: parsedData.scopes,
    };
  } catch (error) {
    console.error('Error loading secrets:', error);
    throw error;
  }
}

async function refreshAccessToken(refreshToken, clientId, clientSecret, tokenUri, scopes = []) {
  const body = new URLSearchParams({
    grant_type: "refresh_token",
    client_id: clientId,
    client_secret: clientSecret,
    refresh_token: refreshToken,
  });

  if (scopes.length > 0) {
    body.append("scope", scopes.join(" "));
  }

  try {
    const response = await fetch(tokenUri, {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: body.toString(),
    });

    const data = await response.json();

    if (!response.ok) {
      console.error("Error Response:", data);
      throw new Error(`${response.status} ${response.statusText} - ${data.error}: ${data.error_description}`);
    }

    return {
      accessToken: data.access_token,
      refreshToken: data.refresh_token || refreshToken, // Use new refresh token if provided
      expiresIn: data.expires_in,
      idToken: data.id_token,
    };
  } catch (error) {
    console.error("Token refresh failed:", error);
    throw error;
  }
}

async function main() {
  try {
    const secrets = await loadSecrets();
    const { refreshToken, clientId, clientSecret, tokenUri, scopes } = secrets;

    refreshAccessToken(refreshToken, clientId, clientSecret, tokenUri, scopes)
      .then((tokens) => console.log("New Access Token:", tokens.accessToken))
      .catch((err) => console.error("Error refreshing token:", err));

  } catch (err) {
    console.error('Error in main function:', err);
  }
}

main();
